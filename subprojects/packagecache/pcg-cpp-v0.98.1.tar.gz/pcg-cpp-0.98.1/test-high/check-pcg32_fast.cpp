#define RNG pcg32_fast
#define TWO_ARG_INIT 0

#include "pcg-test.cpp"

